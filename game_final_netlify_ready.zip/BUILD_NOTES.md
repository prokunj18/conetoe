# Build Notes

- Added `netlify.toml` for Netlify deployment configuration.
- Added `_redirects` file in `public/` for SPA routing.
- No game logic or core files were removed to preserve functionality.
- Project should now deploy faster and more reliably on Netlify.