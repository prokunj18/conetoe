import React from "react";

interface ConePreviewProps {
  color: string;
  isOpponent?: boolean;
  isBench?: boolean;
}

const ConePreview: React.FC<ConePreviewProps> = ({ color, isOpponent = false, isBench = false }) => {
  const gradients: Record<string, { player: string; opponent: string }> = {
    gold: {
      player: "linear-gradient(135deg, #FFD700, #FFC107)",
      opponent: "linear-gradient(135deg, #B8860B, #DAA520)"
    },
    blue: {
      player: "linear-gradient(135deg, #2196F3, #64B5F6)",
      opponent: "linear-gradient(135deg, #0D47A1, #1565C0)"
    },
    red: {
      player: "linear-gradient(135deg, #F44336, #E57373)",
      opponent: "linear-gradient(135deg, #8B0000, #B71C1C)"
    },
    green: {
      player: "linear-gradient(135deg, #4CAF50, #81C784)",
      opponent: "linear-gradient(135deg, #1B5E20, #2E7D32)"
    }
  };

  const gradient = isOpponent ? gradients[color]?.opponent : gradients[color]?.player;

  return (
    <div
      style={{
        width: isBench ? "40px" : "60px",
        height: isBench ? "40px" : "60px",
        borderRadius: "50%",
        background: gradient || color,
        margin: "8px auto"
      }}
    />
  );
};

export default ConePreview;
