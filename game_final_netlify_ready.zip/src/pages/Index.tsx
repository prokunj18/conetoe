import React from "react";
import ConePreview from "../components/game/ConePreview";

const Index: React.FC = () => {
  return (
    <div style={{ textAlign: "center", padding: "40px" }}>
      <h1>Welcome to the Game</h1>
      <div className="player-label">
        <span>Player 1</span>
      </div>
      <div style={{ display: "flex", justifyContent: "center", gap: "20px", marginTop: "20px" }}>
        <ConePreview color="gold" />
        <ConePreview color="blue" />
        <ConePreview color="red" />
        <ConePreview color="green" />
      </div>
    </div>
  );
};

export default Index;
